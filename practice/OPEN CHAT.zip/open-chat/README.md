# Open Chat

The Open Chat application is a simple NodeJS application that enables users to communicate with each other over WebSocket.

### Demo

![Demo](docs/demo.webp)

### Installation


1. **Install the dependencies:**

   1. Navigate to project-directory.
   
        ```
        cd open-chat
        ```   
      
   2. Install the dependencies of backend server.
   
        ```
        npm install
         ```

 ### Usage  

   1. Start the Node.js backend server
   
       ```
       npm run start
       ```
   
   2. Open the **index.html** file located in the **client** folder in your preferred browser.
   
   3. Enter a username and start chatting with other users in real-time!
   